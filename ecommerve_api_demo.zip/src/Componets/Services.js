


import React, { useEffect, useState } from "react";
import Slider from "react-slick";


import Script from "../Componets/Script/Script";
import sliderfirstImg from "../img/shoesbanner.png";
import slidersecoundImg from "../img/buetybanner.png";
import sliderThirdImg from "../img/watchbanner.png";
import sliderFourthImg from "../img/jewellery.png";
import { Link } from "react-router-dom";
import Footer from "./Footer";

function Services() {
  const sliderImages = [sliderfirstImg, slidersecoundImg, sliderThirdImg];
  const [currentSlide, setCurrentSlide] = useState(0);

  const CustomPrevArrow = (props) => (
    <button {...props} className="slick-prev custom-arrow">
      <span>&lt; Previous</span>
    </button>
  );

  const CustomNextArrow = (props) => (
    <button {...props} className="slick-next custom-arrow">
      <span>Next &gt;</span>
    </button>
  );

  const settings = {
    dots: true,
    fade: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    waitForAnimate: false,
    // autoplay: true,
    // autoplaySpeed: 2000,
    // prevArrow: <CustomPrevArrow />,
    // nextArrow: <CustomNextArrow />,
    afterChange: (index) => setCurrentSlide(index) // Update current slide index
  };

  const content = [
    {
      title: 'UP TO 70% OFF',
      description: 'Sneakers',
      button: 'Shop Shoes',
      image: sliderfirstImg,
      id: 1
    },
    {
      title: 'Title 2',
      description: 'Foundation',
      button: 'Shop Makup',
      image: slidersecoundImg,
      id: 2
    },
    {
      title: 'Title 2',
      description: 'Watch',
      button: 'Shop Watch',
      image: sliderThirdImg,
      id: 3
    },
    {
      title: 'Title 2',
      description: 'Watch',
      button: 'Shop Watch',
      image: sliderFourthImg,
      id: 4
    },
  ];
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);


  return (
    <>
      <div className="container-fluid py-5 slider-container">
        <div className="container position-relative">
          <Slider {...settings}>
            {content.map((image, index) => (
              <div key={index} className="position-relative">
                <img
                  src={image.image}
                  className="img-fluid w-100 h-100"
                  alt={`slide-${index}`}
                />
                {/* <div className="container d-flex justify-content-center">
                  <div className="shopbutton position-absolute bottom-0 mb-3 " style={{ right: "69px" }}>

                    {currentSlide == 0 ? <><Link
                      to={`/shop?subcategory=${content[0].description}`}
                      className="btn-large btn-block btn-light  py-2 px-5"
                      style={{
                        width: "200px",
                        fontSize: "28px",
                        color: "#9c4399",
                        fontWeight: "bold",

                        textAlign: "center",
                      }}
                    >
                     
                    </Link>
                      <Link
                        to={`/shop?subcategory=${content[1].description}`}
                        className="btn-large btn-block btn-light  py-2 px-5"
                        style={{ width: "200px", fontSize: "28px", display: "none", color: "#9c4399", fontWeight: "bold" }}
                      >
                       
                      </Link>
                      <Link
                        to={`/shop?subcategory=${content[2].description}`}
                        className="btn-large btn-block btn-light  py-2 px-5"
                        style={{ width: "200px", fontSize: "28px", display: "none", color: "#9c4399", fontWeight: "bold" }}
                      >
                        
                      </Link></> : <></>
                      
                      }

                    {currentSlide == 1 ? <><Link
                      to={`/shop?subcategory=${content[0].description}`}
                      className="btn-large btn-block btn-light  py-2 px-5"
                      style={{ width: "200px", fontSize: "28px", display: "none", color: "#9c4399", fontWeight: "bold" }}
                    >
                  
                    </Link>
                      <Link
                        to={`/shop?subcategory=${content[1].description}`}
                        className="btn-large btn-block btn-light  py-2 px-5"
                        style={{ width: "200px", fontSize: "28px", color: "#9c4399", fontWeight: "bold" }}
                      >
                   
                      </Link>
                      <Link
                        to={`/shop?subcategory=${content[2].description}`}
                        className="btn-large btn-block btn-light  py-2 px-5"
                        style={{ width: "200px", fontSize: "28px", display: "none", color: "#9c4399", fontWeight: "bold" }}
                      >
                   
                      </Link></> : <></>}

                    {currentSlide == 2 ? <><Link
                      to={`/shop?subcategory=${content[0].description}`}
                      className="btn-large btn-block btn-light  py-2 px-5"
                      style={{ width: "200px", fontSize: "28px", display: "none", color: "#9c4399", fontWeight: "bold" }}
                    >
                 
                    </Link>
                      <Link
                        to={`/shop?subcategory=${content[1].description}`}
                        className="btn-large btn-block btn-light  py-2 px-5"
                        style={{ width: "200px", fontSize: "28px", display: "none", color: "#9c4399", fontWeight: "bold" }}
                      >
                   
                      </Link>
                      <Link
                        to={`/shop?subcategory=${content[2].description}`}
                        className="btn-large btn-block btn-light  py-2 px-5"
                        style={{ width: "200px", fontSize: "28px", color: "#9c4399", fontWeight: "bold" }}
                      >
                     
                      </Link></> : <></>}
                  </div>
                </div> */}
              </div>
            ))}
          </Slider>
        </div>
      </div>
      {/* <Footer/> */}
      <Script />
    </>
  );
}

export default Services;

