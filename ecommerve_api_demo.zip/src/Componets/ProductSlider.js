import React from 'react'

const ProductSlider = () => {
  return (
    <div>ProductSlider</div>
  )
}

export default ProductSlider