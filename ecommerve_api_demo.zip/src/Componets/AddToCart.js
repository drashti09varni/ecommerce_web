import React from 'react'

const AddToCart = () => {
    return (
        <div>AddToCart</div>
    )
}

export default AddToCart